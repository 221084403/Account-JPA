/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.bl.AccountFacadeLocal;
import za.ac.tut.model.entites.Account;
import za.ac.tut.model.entites.AccountHolder;

/**
 *
 * @author Student
 */
public class CreateAccountservlet extends HttpServlet
{
    @EJB
    private AccountFacadeLocal afl;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        Account account  = getAccount(request);
        
        String msg = "Account has been created successfully and is stored into database";
        
        afl.create(account);
        
        request.setAttribute("msg", msg);
        
        RequestDispatcher rd = request.getRequestDispatcher("outcome.jsp");
        rd.forward(request, response);
        
     }

    private Account getAccount(HttpServletRequest request)
    {
        Long idNumber = Long.valueOf(request.getParameter("idNumber"));
        String accountType = request.getParameter("accountType");
        Double balance = Double.parseDouble(request.getParameter("balance"));
        Timestamp creationDate = Timestamp.from(Instant.now());
        
        String name  = request.getParameter("name");
        String surname  = request.getParameter("surname");
        String gender = request.getParameter("gender");
        Integer age = Integer.parseInt(request.getParameter("age"));
        
        String [] data = request.getParameter("dateOfBirth").split("-");
        
        Date dateOfBirth =  Date.valueOf(LocalDate.of(Integer.parseInt(data[0]), Integer.parseInt(data[1]), Integer.parseInt(data[2])));
        String status = request.getParameter("status");
        
        AccountHolder holder = new AccountHolder(name, surname, gender, age, dateOfBirth, status);
        
        return new Account(idNumber, accountType, balance, creationDate, holder);
    }
}
