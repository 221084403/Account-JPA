/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.bl.AccountFacadeLocal;
import za.ac.tut.model.entites.Account;

/**
 *
 * @author Student
 */
public class SearchAccountServlet extends HttpServlet 
{
    @EJB
    private AccountFacadeLocal afl;
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        Long idNumber = getIdNumber(request);
        String url = "errorOutcome.jsp";
        String msg  = "Account match this account number is not found";
        
        Account account = afl.find(idNumber);
        
        if(account!=null)
        {
            url = "findAccountOutcome.jsp";
            request.setAttribute("account", account);
        }
        
        request.setAttribute("msg", msg);
        
        RequestDispatcher rd = request.getRequestDispatcher(url);
        rd.forward(request, response);
    }

    private Long getIdNumber(HttpServletRequest request)
    {
        return Long.valueOf(request.getParameter("idNumber"));
    }
}
