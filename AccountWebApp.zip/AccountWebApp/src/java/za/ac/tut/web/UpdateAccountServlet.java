/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.time.Instant;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.bl.AccountFacadeLocal;
import za.ac.tut.model.bl.AccountHolderFacadeLocal;
import za.ac.tut.model.entites.Account;
import za.ac.tut.model.entites.AccountHolder;

/**
 *
 * @author Student
 */
public class UpdateAccountServlet extends HttpServlet 
{
    @EJB
    private AccountFacadeLocal afl;
    @EJB
    private AccountHolderFacadeLocal ahfl;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        Account account = getAccount(request);
        Account accountH = afl.find(account.getId());
        
        AccountHolder holder = accountH.getAccountHolder();
        account.setAccountHolder(holder);
        
        afl.edit(account);
        
        String msg = "Account has been successfully edited";
        
        request.setAttribute("msg", msg);
        
        RequestDispatcher rd = request.getRequestDispatcher("outcome.jsp");
        rd.forward(request, response);
        
    }

    private Account getAccount(HttpServletRequest request) 
    {
        Long idNumber = Long.valueOf(request.getParameter("idNumber"));
        String accountType = request.getParameter("accountType");
        Double balance = Double.parseDouble(request.getParameter("balance"));
        Timestamp creationDate = Timestamp.from(Instant.now());
        
        Account account = new Account();
        account.setId(idNumber);
        account.setCreationDate(creationDate);
        account.setAccountType(accountType);
        account.setBalance(balance);
        
        return account;
    }
}
