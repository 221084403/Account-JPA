/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.bl.AccountFacadeLocal;
import za.ac.tut.model.entites.Account;

/**
 *
 * @author Student
 */
public class DisplayAllAccountServlet extends HttpServlet 
{
    @EJB
    private AccountFacadeLocal afl;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        String url = "errorOutcome.jsp";
        String msg = "Nothing is stored into database";
        
        List<Account> theAccount = afl.findAll();
        
        if(!theAccount.isEmpty())
        {
            url = "displayAllAccountOutcome.jsp";
            request.setAttribute("theAccount", theAccount);
        }
        
        request.setAttribute("msg", msg);
        
        RequestDispatcher rd = request.getRequestDispatcher(url);
        rd.forward(request, response);
    }
}
